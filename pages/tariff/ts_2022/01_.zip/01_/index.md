---
linktitle: 01 สัตว์มีชีวิต
# Page metadata.
title: 01 สัตว์มีชีวิต
date: "2021-12-25T00:00:00Z"
lastmod: "2021-12-25T00:00:00Z"
draft: false  # Is this a draft? true/false
toc: false # Show table of contents? true/false
type: series  # Do not modify.
categories: ["พิกัดศุลกากร"]
tags: ["การยกเว้นอากรตามภาค 4"]
authors: ["admin"]

# Add menu entry to sidebar.
# - name: Declare this menu item as a parent with ID `name`.
# - weight: Position of link in menu.
menu:
  ts_2022:
    parent: รหัสสถิติสินค้า ฉบับปี 2565
    weight: 1

weight: 1
---

<br>

{{< gdocs src="./docs.pdf" >}}


{{< rawhtml >}}
<br>

<br>
<div class="article-tags">
<a class="badge badge-danger" href="./docs.pdf" target="_blank" id="download_files_new">Download</a>

</div>
<br>

{{< /rawhtml >}}

